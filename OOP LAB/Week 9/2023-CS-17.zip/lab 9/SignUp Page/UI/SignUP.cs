﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SignUp_Page.UI
{
    public partial class Sign_Up : Form
    {
        public Sign_Up()
        {
            InitializeComponent();
        }

        private void ClearData()
        {
            UserName.Text = "";
            Password.Text = "";
            Role.Text = "";

            
        }
        private void loadMainform()
        {
            this.Hide();
            Form1 form1 = new Form1();
            form1.Show();
        }
        private void Next_btn(object sender,EventArgs e)
        {
            string username = UserName.Text;
            string password = Password.Text;
            string role = Role.Text;
            string path = "D:\\UET\\OOP\\Lab\\lab 9\\SignUp Page\\bin\\Debugusers.txt";
            BL.MUserBL user = new BL.MUserBL(username, password, role);
            DL.MUserDL.AddUser(user);
            DL.MUserDL.ReadDataFromFile(path);
            DL.MUserDL.StoreUserInFile(user, path);
            MessageBox.Show("User added successfully");
            ClearData();
        }
        private void  BackBtn(object sender,EventArgs e)
        {

            this.Close();
          
        }
       
    }
}
