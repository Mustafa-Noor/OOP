﻿using SignUp_Page.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SignUp_Page.BL;
using SignUp_Page.UI;

namespace SignUp_Page
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            string path= @"C:\Users\user\source\repos\SignUp_Page\SignUp_Page\bin\Debug\users.txt";
            if(MUserDL.ReadDataFromFile(path))
            {
                MessageBox.Show("Data read successfully");
            }
            else
            {
                MessageBox.Show("Data read failed");
            }
        }

       

        private void button1_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                this.Hide();
                UI.Sign_IN sign_IN = new UI.Sign_IN();
                sign_IN.Show();
                this.Show();
            }
            else if (checkBox2.Checked)
            {
                this.Hide();
                UI.Sign_Up sign_Up = new UI.Sign_Up();
                sign_Up.Show();
                this.Show();
            }
           else { MessageBox.Show("Please select one of the options");}
        }
    }
}
