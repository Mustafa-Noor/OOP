﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SignUp_Page.UI
{
    public partial class Sign_IN : Form
    {
        public Sign_IN()
        {
            InitializeComponent();
        }
        private void ClearData()
        {
            Username.Text = "";
            Password.Text = "";
        }
       private void backbtn(object sender,EventArgs e)
        {
            this.Close();
        }
        private void Next_btn(object sender, EventArgs e)
        {
            string username = Username.Text;
            string password = Password.Text;
            BL.MUserBL user = new BL.MUserBL(username, password);
            BL.MUserBL storedUser = DL.MUserDL.SignIn(user);
            if (storedUser != null)
            {
                MessageBox.Show("User signed in successfully");
                if (storedUser.IsAdmin())
                {
                    MessageBox.Show("Welcome Admin");
                }
                else
                {
                    MessageBox.Show("Welcome User");
                }
            }
            else
            {
                MessageBox.Show("Invalid username or password");
            }
            ClearData();
        }

    }
}
