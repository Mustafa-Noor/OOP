﻿namespace FashionIsU_FormsApp_
{
    partial class MainUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.NamePanel = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SignInMenubtn = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.SignUpMenuBtn = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.NamePanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // NamePanel
            // 
            this.NamePanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.NamePanel.Controls.Add(this.label1);
            this.NamePanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.NamePanel.Location = new System.Drawing.Point(0, 0);
            this.NamePanel.Name = "NamePanel";
            this.NamePanel.Size = new System.Drawing.Size(934, 62);
            this.NamePanel.TabIndex = 27;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Palatino Linotype", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(345, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(241, 54);
            this.label1.TabIndex = 2;
            this.label1.Text = "Fashion Is U";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Palatino Linotype", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(376, 91);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(153, 38);
            this.label4.TabIndex = 33;
            this.label4.Text = "Main Page";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Palatino Linotype", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(311, 154);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(280, 32);
            this.label2.TabIndex = 32;
            this.label2.Text = "Welcome To Fashion Is U";
            // 
            // SignInMenubtn
            // 
            this.SignInMenubtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.SignInMenubtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.SignInMenubtn.Font = new System.Drawing.Font("Palatino Linotype", 10F);
            this.SignInMenubtn.Location = new System.Drawing.Point(317, 267);
            this.SignInMenubtn.Name = "SignInMenubtn";
            this.SignInMenubtn.Size = new System.Drawing.Size(274, 60);
            this.SignInMenubtn.TabIndex = 37;
            this.SignInMenubtn.Text = "Open Sign In Page";
            this.SignInMenubtn.UseVisualStyleBackColor = false;
            this.SignInMenubtn.Click += new System.EventHandler(this.SignInMenubtn_Click);
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(328, 209);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(258, 27);
            this.label3.TabIndex = 38;
            this.label3.Text = "Select One Of the Options: ";
            // 
            // SignUpMenuBtn
            // 
            this.SignUpMenuBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.SignUpMenuBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.SignUpMenuBtn.Font = new System.Drawing.Font("Palatino Linotype", 10F);
            this.SignUpMenuBtn.Location = new System.Drawing.Point(317, 362);
            this.SignUpMenuBtn.Name = "SignUpMenuBtn";
            this.SignUpMenuBtn.Size = new System.Drawing.Size(274, 60);
            this.SignUpMenuBtn.TabIndex = 39;
            this.SignUpMenuBtn.Text = "Open Sign Up Page";
            this.SignUpMenuBtn.UseVisualStyleBackColor = false;
            this.SignUpMenuBtn.Click += new System.EventHandler(this.SignUpMenuBtn_Click);
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(212, 470);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(496, 27);
            this.label5.TabIndex = 40;
            this.label5.Text = "Hope You Have A Wonderful Experience At Our Store";
            // 
            // MainUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(934, 561);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.SignUpMenuBtn);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.SignInMenubtn);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.NamePanel);
            this.MinimumSize = new System.Drawing.Size(952, 608);
            this.Name = "MainUI";
            this.Text = "Form1";
            this.NamePanel.ResumeLayout(false);
            this.NamePanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel NamePanel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button SignInMenubtn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button SignUpMenuBtn;
        private System.Windows.Forms.Label label5;
    }
}

