﻿namespace FashionIsU_FormsApp_.UI
{
    partial class UpdateProfileCustomerUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.ReviewPageLabel = new System.Windows.Forms.Label();
            this.UsernameLabel = new System.Windows.Forms.Label();
            this.contact = new System.Windows.Forms.TextBox();
            this.lastName = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.firstName = new System.Windows.Forms.TextBox();
            this.email = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.password = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.UpdateProfileBtn = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel1.Controls.Add(this.ReviewPageLabel);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(884, 53);
            this.panel1.TabIndex = 8;
            // 
            // ReviewPageLabel
            // 
            this.ReviewPageLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ReviewPageLabel.AutoSize = true;
            this.ReviewPageLabel.BackColor = System.Drawing.Color.Transparent;
            this.ReviewPageLabel.Cursor = System.Windows.Forms.Cursors.No;
            this.ReviewPageLabel.Font = new System.Drawing.Font("Palatino Linotype", 20F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ReviewPageLabel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.ReviewPageLabel.Location = new System.Drawing.Point(259, 8);
            this.ReviewPageLabel.Name = "ReviewPageLabel";
            this.ReviewPageLabel.Size = new System.Drawing.Size(323, 45);
            this.ReviewPageLabel.TabIndex = 2;
            this.ReviewPageLabel.Text = "Update Profile Page";
            this.ReviewPageLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // UsernameLabel
            // 
            this.UsernameLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.UsernameLabel.AutoSize = true;
            this.UsernameLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.UsernameLabel.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.UsernameLabel.Font = new System.Drawing.Font("Palatino Linotype", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UsernameLabel.Location = new System.Drawing.Point(238, 86);
            this.UsernameLabel.Name = "UsernameLabel";
            this.UsernameLabel.Size = new System.Drawing.Size(223, 33);
            this.UsernameLabel.TabIndex = 53;
            this.UsernameLabel.Text = "Your Username is :";
            // 
            // contact
            // 
            this.contact.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.contact.Font = new System.Drawing.Font("Palatino Linotype", 10F);
            this.contact.Location = new System.Drawing.Point(400, 400);
            this.contact.Name = "contact";
            this.contact.Size = new System.Drawing.Size(235, 30);
            this.contact.TabIndex = 84;
            // 
            // lastName
            // 
            this.lastName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lastName.Font = new System.Drawing.Font("Palatino Linotype", 10F);
            this.lastName.Location = new System.Drawing.Point(400, 346);
            this.lastName.Name = "lastName";
            this.lastName.Size = new System.Drawing.Size(235, 30);
            this.lastName.TabIndex = 83;
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Palatino Linotype", 13F);
            this.label8.Location = new System.Drawing.Point(225, 398);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(127, 29);
            this.label8.TabIndex = 82;
            this.label8.Text = "Contact No";
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Palatino Linotype", 13F);
            this.label9.Location = new System.Drawing.Point(231, 344);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(121, 29);
            this.label9.TabIndex = 81;
            this.label9.Text = "Last Name";
            // 
            // firstName
            // 
            this.firstName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.firstName.Font = new System.Drawing.Font("Palatino Linotype", 10F);
            this.firstName.Location = new System.Drawing.Point(400, 291);
            this.firstName.Name = "firstName";
            this.firstName.Size = new System.Drawing.Size(235, 30);
            this.firstName.TabIndex = 80;
            // 
            // email
            // 
            this.email.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.email.Font = new System.Drawing.Font("Palatino Linotype", 10F);
            this.email.Location = new System.Drawing.Point(401, 237);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(234, 30);
            this.email.TabIndex = 79;
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Palatino Linotype", 13F);
            this.label6.Location = new System.Drawing.Point(231, 289);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(124, 29);
            this.label6.TabIndex = 78;
            this.label6.Text = "First Name";
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Palatino Linotype", 13F);
            this.label7.Location = new System.Drawing.Point(248, 235);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(69, 29);
            this.label7.TabIndex = 77;
            this.label7.Text = "Email";
            // 
            // password
            // 
            this.password.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.password.Font = new System.Drawing.Font("Palatino Linotype", 10F);
            this.password.Location = new System.Drawing.Point(400, 187);
            this.password.Name = "password";
            this.password.Size = new System.Drawing.Size(235, 30);
            this.password.TabIndex = 76;
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Palatino Linotype", 13F);
            this.label3.Location = new System.Drawing.Point(151, 185);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(204, 29);
            this.label3.TabIndex = 75;
            this.label3.Text = "Password (6-Digits)";
            // 
            // UpdateProfileBtn
            // 
            this.UpdateProfileBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.UpdateProfileBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.UpdateProfileBtn.Font = new System.Drawing.Font("Palatino Linotype", 12F);
            this.UpdateProfileBtn.Location = new System.Drawing.Point(324, 514);
            this.UpdateProfileBtn.Name = "UpdateProfileBtn";
            this.UpdateProfileBtn.Size = new System.Drawing.Size(209, 60);
            this.UpdateProfileBtn.TabIndex = 85;
            this.UpdateProfileBtn.Text = "Update Profile";
            this.UpdateProfileBtn.UseVisualStyleBackColor = false;
            this.UpdateProfileBtn.Click += new System.EventHandler(this.UpdateProfileBtn_Click);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // UpdateProfileUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 661);
            this.Controls.Add(this.UpdateProfileBtn);
            this.Controls.Add(this.contact);
            this.Controls.Add(this.lastName);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.firstName);
            this.Controls.Add(this.email);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.password);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.UsernameLabel);
            this.Controls.Add(this.panel1);
            this.Name = "UpdateProfileUI";
            this.Text = "UpdateProfileUI";
            this.Load += new System.EventHandler(this.UpdateProfileUI_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label ReviewPageLabel;
        private System.Windows.Forms.Label UsernameLabel;
        private System.Windows.Forms.TextBox contact;
        private System.Windows.Forms.TextBox lastName;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox firstName;
        private System.Windows.Forms.TextBox email;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox password;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button UpdateProfileBtn;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}